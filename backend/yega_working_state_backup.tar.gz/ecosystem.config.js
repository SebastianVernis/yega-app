module.exports = {
  apps : [{
    name: 'yega',
    script: '/var/www/yega/backend/server.js',
    cwd: '/var/www/yega/backend',
    env_production: {
      NODE_ENV: 'production',
      NODE_PATH: '/var/www/yega/backend/node_modules'
    }
  }]
};
