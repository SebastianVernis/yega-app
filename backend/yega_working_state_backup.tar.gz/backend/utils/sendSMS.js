// backend/utils/sendSMS.js
const dotenv = require('dotenv');

dotenv.config();

// Dummy client for Twilio logic removal
let client = { messages: { create: async () => ({ sid: 'dummy_sid', status: 'queued' }) } };

/**
 * Envía un SMS (dummy implementation after Twilio removal)
 * @param {string} to - Número de teléfono destino (formato internacional)
 * @param {string} message - Mensaje a enviar
 * @returns {Promise<Object>} Resultado del envío
 */
const sendSMS = async (to, message) => {
  console.log(`[DUMMY SMS] Simulando envío de SMS a ${to}: ${message}`);
  return {
    success: true,
    sid: 'dummy_' + Date.now(),
    status: 'sent',
    to: to,
    simulated: true
  };
};

/**
 * Envía SMS de verificación OTP (dummy implementation)
 * @param {string} to - Número de teléfono
 * @param {string} otp - Código OTP
 * @param {string} appName - Nombre de la aplicación
 * @returns {Promise<Object>} Resultado del envío
 */
const sendOTPSMS = async (to, otp, appName = 'YEGA') => {
  const message = `Tu código de verificación de ${appName} es: ${otp}. Este código expira en 10 minutos.`;
  return await sendSMS(to, message);
};

/**
 * Envía SMS de notificación de pedido (dummy implementation)
 * @param {string} to - Número de teléfono
 * @param {string} orderNumber - Número de pedido
 * @param {string} status - Estado del pedido
 * @returns {Promise<Object>} Resultado del envío
 */
const sendOrderNotificationSMS = async (to, orderNumber, status) => {
  const statusMessages = {
    confirmado: 'Tu pedido ha sido confirmado y está siendo preparado',
    listo: 'Tu pedido está listo para ser enviado',
    en_camino: 'Tu pedido está en camino',
    entregado: 'Tu pedido ha sido entregado exitosamente'
  };

  const message = `YEGA - Pedido ${orderNumber}: ${statusMessages[status] || 'Estado actualizado'}.`;
  return await sendSMS(to, message);
};

/**
 * Valida formato de número de teléfono
 * @param {string} phoneNumber - Número a validar
 * @returns {boolean} True si es válido
 */
const isValidPhoneNumber = (phoneNumber) => {
  if (!phoneNumber || typeof phoneNumber !== 'string') return false;
  
  // Formato internacional básico: +[código país][número]
  const phoneRegex = /^\+?[1-9]\d{1,14}$/;
  return phoneRegex.test(phoneNumber.replace(/\s+/g, ''));
};

/**
 * Formatea número de teléfono para Twilio
 * @param {string} phoneNumber - Número a formatear
 * @returns {string} Número formateado
 */
const formatPhoneNumber = (phoneNumber) => {
  // Remover espacios y caracteres especiales
  let formatted = phoneNumber.replace(/[^\d+]/g, '');
  
  // Agregar + si no lo tiene
  if (!formatted.startsWith('+')) {
    formatted = '+' + formatted;
  }
  
  return formatted;
};

module.exports = {
  sendSMS,
  sendOTPSMS,
  sendOrderNotificationSMS,
  isValidPhoneNumber,
  formatPhoneNumber
};