# Project Overview

This project is a Node.js backend for an e-commerce platform. It uses the Express.js framework and MongoDB with Mongoose for the database. The backend provides RESTful APIs for managing products and users, including user registration and login with JWT-based authentication.

## Main Technologies

*   **Node.js:** JavaScript runtime environment.
*   **Express.js:** Web application framework for Node.js.
*   **MongoDB:** NoSQL database.
*   **Mongoose:** ODM library for MongoDB and Node.js.
*   **JSON Web Tokens (JWT):** For user authentication.
*   **Bcrypt:** For password hashing.

## Architecture

The project follows a standard Model-View-Controller (MVC) like architecture, with:

*   **`models/`:** Contains the Mongoose schemas and models for the database collections (e.g., `Producto.js`).
*   **`routes/`:** Defines the API endpoints and their corresponding logic (e.g., `productosList.js`, `usuariosLogin.js`).

There is also a script `generate-backend.js` that seems to be a helper tool to generate code for the project, possibly by using an AI model.

# Building and Running

The project does not have a `package.json` file, so the exact commands for building and running the project are not explicitly defined. However, based on the file contents, the following commands are likely to be used:

**Installation:**

```bash
# TODO: Create a package.json file and add dependencies.
npm install express mongoose jsonwebtoken bcrypt
```

**Running the application:**

```bash
# TODO: Create a main server file (e.g., index.js or app.js)
node index.js
```

# Development Conventions

*   **Authentication:** User authentication is handled using JWT. Passwords are hashed using bcrypt before being stored in the database.
*   **API Design:** The API is designed to be RESTful. For example, `GET /productos` retrieves a list of products, and `POST /usuarios/login` is used for user login.
*   **Code Generation:** The project includes scripts for code generation (`generate-backend.js`, `generate-endpoint.js`), which suggests a convention of using these tools to scaffold new features.

# Gemini CLI Assistant Role

As the Gemini CLI Assistant, my primary role is to assist in maintaining the health and integrity of this application. I can help with:

*   **Code Health Checks:** I can analyze code for potential issues, suggest improvements, and help enforce coding standards.
*   **Integrity Verification:** I can assist in verifying the integrity of the codebase by running tests, linters, and type checkers.
*   **Troubleshooting:** I can help diagnose and resolve issues, such as the Content Security Policy problem we just fixed.
*   **Code Modifications:** I can perform code modifications, refactoring, and feature additions while adhering to existing project conventions.
*   **Documentation:** I can help update and maintain project documentation, like this `GEMINI.md` file.

Feel free to ask me to perform any of these tasks or provide guidance on how to do them.