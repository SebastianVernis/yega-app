const mongoose = require('mongoose');
const dotenv = require('dotenv');

dotenv.config({ path: __dirname + '/../.env' });

async function testConnection() {
  const uri = process.env.MONGODB_URI;
  console.log('URI:', uri ? 'Definido' : 'No definido');
  
  try {
    console.log('Intentando conectar...');
    await mongoose.connect(uri);
    console.log('✅ Conexión exitosa');
    
    // Test básico
    const collections = await mongoose.connection.db.listCollections().toArray();
    console.log('Colecciones encontradas:', collections.map(c => c.name));
    
  } catch (error) {
    console.error('❌ Error de conexión:', error.message);
  } finally {
    await mongoose.disconnect();
  }
}

testConnection();