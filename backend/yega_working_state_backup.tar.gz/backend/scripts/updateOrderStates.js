// Script para actualizar pedidos existentes con los nuevos estados
const mongoose = require('mongoose');
const Pedido = require('../models/Pedido');
require('dotenv').config();

const updateExistingOrders = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/yega');
    console.log('✅ Conectado a MongoDB');

    // No necesitamos migrar datos, solo verificar que los estados existen
    const estados = await Pedido.distinct('estado');
    console.log('📊 Estados encontrados en la BD:', estados);

    // Verificar que los nuevos estados están en el enum
    const schema = Pedido.schema.paths.estado;
    console.log('✅ Estados válidos en el modelo:', schema.enumValues);

    console.log('✅ Migración completada - Los nuevos estados están disponibles');
    
  } catch (error) {
    console.error('❌ Error en migración:', error);
  } finally {
    await mongoose.disconnect();
  }
};

updateExistingOrders();