// Script para limpiar y recargar datos demo
const mongoose = require('mongoose');
const dotenv = require('dotenv');

dotenv.config({ path: __dirname + '/../.env' });

const Usuario = require('../models/Usuario');
const Producto = require('../models/Producto');
const Pedido = require('../models/Pedido');
const OTP = require('../models/OTP');

async function cleanAll() {
  console.log('🧹 Limpiando base de datos...');
  
  await Pedido.deleteMany({});
  await Producto.deleteMany({});
  await OTP.deleteMany({});
  await Usuario.deleteMany({});
  
  console.log('✅ Base de datos limpia');
}

async function seedUsers() {
  console.log('👥 Creando usuarios demo...');
  
  const usuarios = [
    {
      nombre: 'Admin YEGA',
      telefono: '+10000000000',
      email: 'admin@yega.local',
      password: 'admin123',
      rol: 'administrador',
      estado_validacion: 'aprobado',
      activo: true
    },
    {
      nombre: 'Tienda Demo',
      telefono: '+10000000001',
      email: 'tienda@yega.local',
      password: 'tienda123',
      rol: 'tienda',
      estado_validacion: 'aprobado',
      activo: true,
      ubicacion: { latitud: -34.6037, longitud: -58.3816, direccion: 'Av. Corrientes 123, CABA' }
    },
    {
      nombre: 'Cliente Prueba',
      telefono: '+10000000002',
      email: 'cliente@yega.local',
      password: 'cliente123',
      rol: 'cliente',
      estado_validacion: 'aprobado',
      activo: true,
    },
    {
      nombre: 'Repartidor Prueba',
      telefono: '+10000000003',
      email: 'repartidor@yega.local',
      password: 'repartidor123',
      rol: 'repartidor',
      estado_validacion: 'aprobado',
      activo: true,
      ubicacion: { latitud: -34.6037, longitud: -58.3816, direccion: 'CABA, AR' },
    }
  ];

  for (const userData of usuarios) {
    const user = new Usuario(userData);
    await user.save();
    console.log(`✅ Usuario creado: ${user.email} (${user.rol})`);
  }
}

async function seedProducts() {
  console.log('🍔 Creando productos demo...');
  
  const tienda = await Usuario.findOne({ email: 'tienda@yega.local' });
  
  const productos = [
    {
      nombre: 'Hamburguesa Clásica',
      descripcion: 'Doble carne con queso cheddar, lechuga y tomate',
      precio: 12.99,
      stock: 50,
      tiendaId: tienda._id,
      categoria: 'comida',
      tags: ['hamburguesa', 'carne']
    },
    {
      nombre: 'Pizza Margherita',
      descripcion: 'Salsa de tomate, mozzarella fresca y albahaca',
      precio: 16.50,
      stock: 30,
      tiendaId: tienda._id,
      categoria: 'comida',
      tags: ['pizza', 'vegetariana']
    },
    {
      nombre: 'Ensalada César',
      descripcion: 'Lechuga, pollo grillado, crutones y aderezo césar',
      precio: 9.99,
      stock: 25,
      tiendaId: tienda._id,
      categoria: 'ensalada',
      tags: ['ensalada', 'saludable']
    }
  ];

  for (const productData of productos) {
    const product = new Producto(productData);
    await product.save();
    console.log(`✅ Producto creado: ${product.nombre}`);
  }
}

async function seedOrders() {
  console.log('📦 Creando pedidos demo...');
  
  const tienda = await Usuario.findOne({ email: 'tienda@yega.local' });
  const cliente = await Usuario.findOne({ email: 'cliente@yega.local' });
  const repartidor = await Usuario.findOne({ email: 'repartidor@yega.local' });
  const producto = await Producto.findOne({ tiendaId: tienda._id });

  const direccion_envio = {
    calle: 'Av. Demo',
    numero: '456',
    ciudad: 'CABA',
    codigo_postal: '1000',
    referencias: 'Piso 3, Depto B',
    latitud: -34.6037,
    longitud: -58.3816,
  };

  const estados = [
    { estado: 'pendiente', asignado: false, descripcion: 'Pedido recién creado' },
    { estado: 'confirmado', asignado: false, descripcion: 'Confirmado por la tienda' },
    { estado: 'preparando', asignado: false, descripcion: 'Siendo preparado' },
    { estado: 'listo', asignado: true, descripcion: 'Listo para recoger' },
    { estado: 'camino_tienda', asignado: true, descripcion: 'Repartidor en camino a la tienda' },
    { estado: 'recolectado', asignado: true, descripcion: 'Producto recolectado de la tienda' },
    { estado: 'en_camino', asignado: true, descripcion: 'En camino al cliente' },
    { estado: 'entregado', asignado: true, descripcion: 'Pedido entregado' }
  ];

  for (let i = 0; i < estados.length; i++) {
    const { estado, asignado, descripcion } = estados[i];
    const cantidad = 1;
    const subtotal_item = producto.precio * cantidad;
    const costo_envio = 2.50;
    const total = subtotal_item + costo_envio;

    const numero_pedido = `YEGA-${String(i + 1).padStart(6, '0')}`;

    const pedido = new Pedido({
      numero_pedido,
      clienteId: cliente._id,
      tiendaId: tienda._id,
      repartidorId: asignado ? repartidor._id : undefined,
      productos: [{
        producto: producto._id,
        cantidad,
        precio_unitario: producto.precio,
        subtotal: subtotal_item,
      }],
      subtotal: subtotal_item,
      costo_envio,
      total,
      estado,
      direccion_envio,
      metodo_pago: 'efectivo',
      notas: `Pedido DEMO - ${descripcion}`,
      tiempo_estimado: 30,
    });

    await pedido.save();
    console.log(`✅ Pedido creado: ${pedido.numero_pedido} - ${estado} (${descripcion})`);
  }
}

async function main() {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    console.error('❌ MONGODB_URI no definido. Revisa backend/.env');
    process.exit(1);
  }

  console.log('🔄 Conectando a MongoDB...');
  await mongoose.connect(uri);
  console.log('✅ Conectado a MongoDB');

  try {
    await cleanAll();
    await seedUsers();
    await seedProducts();
    await seedOrders();
    
    console.log('🎉 Seed completo exitoso!');
    console.log('');
    console.log('Usuarios creados:');
    console.log('  - admin@yega.local (admin123)');
    console.log('  - tienda@yega.local (tienda123)');
    console.log('  - cliente@yega.local (cliente123)');
    console.log('  - repartidor@yega.local (repartidor123)');
    console.log('');
    console.log('Se crearon pedidos con todos los estados nuevos:');
    console.log('  - pendiente, confirmado, preparando, listo');
    console.log('  - camino_tienda, recolectado, en_camino, entregado');
    
  } catch (error) {
    console.error('❌ Error durante el seed:', error);
    throw error;
  } finally {
    await mongoose.disconnect();
    console.log('🔌 Desconectado de MongoDB');
  }
}

main().catch((err) => {
  console.error('❌ Error fatal:', err);
  process.exit(1);
});