/**
 * Script para limpieza de base de datos antes del despliegue
 * 
 * Este script:
 * 1. Elimina todos los usuarios excepto administrador
 * 2. Elimina todos los pedidos
 * 3. Elimina todos los productos
 * 4. Elimina todos los OTPs
 * 5. Mantiene SOLO el usuario admin@yega.local
 */

const mongoose = require('mongoose');
const dotenv = require('dotenv');
const path = require('path');

// Cargar variables de entorno
dotenv.config({ path: path.join(__dirname, '..', '.env') });

// Importar modelos
const Usuario = require('../models/Usuario');
const OTP = require('../models/OTP');
const Producto = require('../models/Producto');
const Pedido = require('../models/Pedido');

// Configuración
const ADMIN_EMAIL = 'admin@yega.local';
const PRESERVE_PRODUCTS = false; // Cambiar a true si deseas mantener los productos

async function main() {
  const uri = process.env.MONGODB_URI;
  const dryRun = process.argv.includes('--dry');
  const preserveProducts = PRESERVE_PRODUCTS || process.argv.includes('--keep-products');

  // Verificar que tenemos la URI de MongoDB
  if (!uri) {
    console.error('❌ MONGODB_URI no definido. Verifica el archivo .env en la carpeta backend');
    process.exit(1);
  }

  console.log('🔄 Conectando a la base de datos...');
  try {
    await mongoose.connect(uri);
    console.log('✅ Conexión exitosa a MongoDB');
  } catch (error) {
    console.error('❌ Error de conexión a MongoDB:', error.message);
    process.exit(1);
  }

  // Verificar que el usuario admin existe
  const keepEmails = [ADMIN_EMAIL];
  const keepUsers = await Usuario.find({ email: { $in: keepEmails } }).select('_id email rol');

  if (keepUsers.length < keepEmails.length) {
    console.warn('⚠️ Advertencia: No se encontró el usuario administrador:', ADMIN_EMAIL);
    const continuar = process.argv.includes('--force');
    if (!continuar && !dryRun) {
      console.error('❌ Abortando para evitar eliminar todos los usuarios. Usa --force para continuar de todos modos.');
      await mongoose.disconnect();
      process.exit(1);
    }
  }

  // Estadísticas antes de la limpieza
  const allUsers = await Usuario.find().select('_id email rol');
  const toDelete = allUsers.filter(u => !keepEmails.includes(u.email));
  const pedidosCount = await Pedido.countDocuments();
  const productosCount = await Producto.countDocuments();
  const otpsCount = await OTP.countDocuments();

  console.log('\n📊 ESTADÍSTICAS ANTES DE LA LIMPIEZA:');
  console.log(`• Usuarios totales: ${allUsers.length}`);
  console.log(`• Pedidos: ${pedidosCount}`);
  console.log(`• Productos: ${productosCount}`);
  console.log(`• OTPs: ${otpsCount}`);
  console.log(`\n👤 Usuario a conservar: ${keepUsers.map(u => `${u.email} (${u.rol})`).join(', ')}`);
  console.log(`\n🗑️ Usuarios a eliminar (${toDelete.length}):`);
  
  // Mostrar usuarios a eliminar en formato tabla
  if (toDelete.length > 0) {
    const table = toDelete.map(u => `  • ${u.email.padEnd(30)} | ${u.rol}`);
    console.log(table.join('\n'));
  }

  // En modo prueba, no realizar cambios
  if (dryRun) {
    console.log('\n🔍 MODO PRUEBA ACTIVADO. No se realizaron cambios en la base de datos.');
    await mongoose.disconnect();
    return;
  }

  // Confirmar antes de proceder
  if (!process.argv.includes('--yes')) {
    console.log('\n⚠️ ATENCIÓN: Esta operación eliminará permanentemente los datos mencionados anteriormente.');
    console.log('Para continuar, ejecuta el script con el argumento --yes');
    console.log('Ejemplo: node scripts/cleanBeforeDeploy.js --yes');
    await mongoose.disconnect();
    return;
  }

  console.log('\n🧹 INICIANDO LIMPIEZA DE BASE DE DATOS...');

  // 1. Eliminar pedidos
  if (pedidosCount > 0) {
    try {
      const delPedidos = await Pedido.deleteMany({});
      console.log(`✅ Pedidos eliminados: ${delPedidos.deletedCount}`);
    } catch (error) {
      console.error('❌ Error al eliminar pedidos:', error.message);
    }
  }

  // 2. Eliminar productos (opcional)
  if (productosCount > 0 && !preserveProducts) {
    try {
      const delProductos = await Producto.deleteMany({});
      console.log(`✅ Productos eliminados: ${delProductos.deletedCount}`);
    } catch (error) {
      console.error('❌ Error al eliminar productos:', error.message);
    }
  } else if (preserveProducts) {
    console.log('ℹ️ Se conservaron los productos según configuración.');
  }

  // 3. Eliminar OTPs
  if (otpsCount > 0) {
    try {
      const delOtps = await OTP.deleteMany({});
      console.log(`✅ OTPs eliminados: ${delOtps.deletedCount}`);
    } catch (error) {
      console.error('❌ Error al eliminar OTPs:', error.message);
    }
  }

  // 4. Eliminar todos los usuarios excepto admin
  try {
    const delUsers = await Usuario.deleteMany({ email: { $nin: keepEmails } });
    console.log(`✅ Usuarios eliminados: ${delUsers.deletedCount}`);
  } catch (error) {
    console.error('❌ Error al eliminar usuarios:', error.message);
  }

  // Verificación final
  const remainingUsers = await Usuario.countDocuments();
  const remainingPedidos = await Pedido.countDocuments();
  const remainingProductos = await Producto.countDocuments();
  const remainingOTPs = await OTP.countDocuments();

  console.log('\n📊 ESTADÍSTICAS DESPUÉS DE LA LIMPIEZA:');
  console.log(`• Usuarios restantes: ${remainingUsers}`);
  console.log(`• Pedidos restantes: ${remainingPedidos}`);
  console.log(`• Productos restantes: ${remainingProductos}`);
  console.log(`• OTPs restantes: ${remainingOTPs}`);

  await mongoose.disconnect();
  console.log('\n✅ LIMPIEZA COMPLETADA. Base de datos preparada para despliegue.');
}

main().catch((err) => {
  console.error('\n❌ ERROR GENERAL:', err.message);
  process.exit(1);
});