const mongoose = require('mongoose');
const dotenv = require('dotenv');

dotenv.config({ path: __dirname + '/../.env' });

const Usuario = require('../models/Usuario');
const OTP = require('../models/OTP');
const Producto = require('../models/Producto');
const Pedido = require('../models/Pedido');

const ADMIN_EMAIL = 'admin@yega.local';

async function main() {
  const uri = process.env.MONGODB_URI;
  const dryRun = process.argv.includes('--dry');

  if (!uri) {
    console.error('MONGODB_URI no definido. Revisa backend/.env');
    process.exit(1);
  }

  console.log('[clean] Conectando a la base de datos...');
  await mongoose.connect(uri);

  const keepEmails = [ADMIN_EMAIL];
  const keepUsers = await Usuario.find({ email: { $in: keepEmails } }).select('_id email rol');

  if (keepUsers.length < keepEmails.length) {
    console.warn('[clean] Advertencia: No se encontró el usuario administrador:', ADMIN_EMAIL);
    if (!dryRun) {
      console.error('[clean] Abortando para evitar eliminar todos los usuarios');
      process.exit(1);
    }
  }

  const allUsers = await Usuario.find().select('_id email rol');
  const toDelete = allUsers.filter(u => !keepEmails.includes(u.email));

  const pedidosCount = await Pedido.countDocuments();
  const productosCount = await Producto.countDocuments();

  console.log(`[clean] Usuarios totales: ${allUsers.length}`);
  console.log(`[clean] Pedidos: ${pedidosCount}`);
  console.log(`[clean] Productos: ${productosCount}`);
  console.log(`[clean] Usuario a conservar: ${keepUsers.map(u => `${u.email} (${u.rol})`).join(', ')}`);
  console.log(`[clean] Usuarios a eliminar (${toDelete.length}):`, toDelete.map(u => `${u.email} (${u.rol})`));

  if (dryRun) {
    console.log('[clean] Modo prueba (--dry). No se realizaron cambios.');
    await mongoose.disconnect();
    return;
  }

  // Eliminar pedidos
  if (pedidosCount > 0) {
    const delPedidos = await Pedido.deleteMany({});
    console.log(`[clean] Pedidos eliminados: ${delPedidos.deletedCount}`);
  }

  // Eliminar productos
  if (productosCount > 0) {
    const delProductos = await Producto.deleteMany({});
    console.log(`[clean] Productos eliminados: ${delProductos.deletedCount}`);
  }

  // Eliminar OTPs asociados a los usuarios que se eliminarán
  const deleteEmails = toDelete.map(u => u.email);
  const deletePhones = toDelete.map(u => u.telefono).filter(Boolean);

  const otpFilter = { $or: [] };
  if (deleteEmails.length) otpFilter.$or.push({ email: { $in: deleteEmails } });
  if (deletePhones.length) otpFilter.$or.push({ telefono: { $in: deletePhones } });

  if (otpFilter.$or.length) {
    const delOtps = await OTP.deleteMany(otpFilter);
    console.log(`[clean] OTPs eliminados: ${delOtps.deletedCount}`);
  } else {
    console.log('[clean] No hay OTPs para eliminar');
  }

  // Eliminar todos los usuarios excepto admin
  const delUsers = await Usuario.deleteMany({ email: { $nin: keepEmails } });
  console.log(`[clean] Usuarios eliminados: ${delUsers.deletedCount}`);

  await mongoose.disconnect();
  console.log('[clean] Base de datos limpia. Solo queda el usuario administrador.');
}

main().catch((err) => {
  console.error('[clean] Error:', err);
  process.exit(1);
});