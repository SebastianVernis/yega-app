// cors-fix.js - Script para verificar y corregir la configuración de CORS
const fs = require('fs');
const path = require('path');

// Comprobar el servidor.js
const serverPath = path.join(__dirname, 'server.js');
console.log('Verificando:', serverPath);

if (fs.existsSync(serverPath)) {
  let serverContent = fs.readFileSync(serverPath, 'utf8');
  
  // Buscar la configuración de CORS
  if (serverContent.includes('cors({')) {
    console.log('Configuración de CORS encontrada, actualizando...');
    
    // Reemplazar la configuración de CORS para permitir todos los orígenes
    const corsRegex = /app\.use\(\s*cors\(\s*\{[^}]*\}\s*\)\s*\)/gs;
    const newCorsConfig = "app.use(cors({\n  origin: '*',\n  credentials: true\n}))";
    
    const updatedContent = serverContent.replace(corsRegex, newCorsConfig);
    
    if (updatedContent !== serverContent) {
      fs.writeFileSync(serverPath, updatedContent);
      console.log('Configuración de CORS actualizada correctamente');
    } else {
      console.log('No se requirieron cambios en la configuración de CORS');
    }
  } else {
    console.log('No se encontró configuración de CORS existente, agregando...');
    
    // Buscar donde importar cors
    const importRegex = /const express = require\('express'\);/;
    const corsImport = "const express = require('express');\nconst cors = require('cors');";
    
    // Buscar donde usar cors
    const appRegex = /const app = express\(\);/;
    const corsConfig = "const app = express();\n\n// Configurar CORS\napp.use(cors({\n  origin: '*',\n  credentials: true\n}));";
    
    // Aplicar los cambios
    let updatedContent = serverContent;
    if (!serverContent.includes("const cors = require('cors')")) {
      updatedContent = updatedContent.replace(importRegex, corsImport);
    }
    if (!serverContent.includes("app.use(cors(")) {
      updatedContent = updatedContent.replace(appRegex, corsConfig);
    }
    
    if (updatedContent !== serverContent) {
      fs.writeFileSync(serverPath, updatedContent);
      console.log('Configuración de CORS agregada correctamente');
    } else {
      console.log('No se pudieron aplicar cambios de CORS');
    }
  }
} else {
  console.error('El archivo server.js no existe');
}

// Comprobar el cliente API en el frontend
const apiClientPath = path.join('/var/www/yega/frontend', 'src', 'services', 'apiClient.js');
console.log('Verificando:', apiClientPath);

if (fs.existsSync(apiClientPath)) {
  let apiClientContent = fs.readFileSync(apiClientPath, 'utf8');
  
  // Corregir la inicialización de la URL base
  const apiBaseUrlRegex = /const rawApiUrl = [^\n]*;\s*const API_BASE_URL = [^\n]*;/s;
  const newApiBaseUrl = "const rawApiUrl = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';\n" +
                         "// Asegurarse de que la URL termine en /api\n" +
                         "const API_BASE_URL = rawApiUrl;";
  
  if (apiClientContent.includes(apiBaseUrlRegex)) {
    const updatedContent = apiClientContent.replace(apiBaseUrlRegex, newApiBaseUrl);
    
    if (updatedContent !== apiClientContent) {
      fs.writeFileSync(apiClientPath, updatedContent);
      console.log('Configuración de API_BASE_URL corregida en apiClient.js');
    } else {
      console.log('No se requirieron cambios en apiClient.js');
    }
  } else {
    console.log('No se encontró el patrón de configuración de API_BASE_URL en apiClient.js');
  }
} else {
  console.error('El archivo apiClient.js no existe');
}

console.log('Proceso de corrección de CORS completado');
